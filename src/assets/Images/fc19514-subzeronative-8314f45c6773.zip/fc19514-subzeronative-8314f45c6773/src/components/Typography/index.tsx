import Typography from './Typography';
import { TypographyProps } from './Typography.type';

export type { TypographyProps };

export default Typography;