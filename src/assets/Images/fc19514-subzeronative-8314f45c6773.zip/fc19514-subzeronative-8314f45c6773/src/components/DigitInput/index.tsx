import DigitInput from './DigitInput';
import { DigitInputProps } from './DigitInput.type';

export type { DigitInputProps };

export default DigitInput;