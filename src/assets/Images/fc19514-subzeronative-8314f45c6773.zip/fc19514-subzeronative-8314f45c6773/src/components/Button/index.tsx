import Button from './Button';
import { ButtonProps } from './Button.type';

export type { ButtonProps };

export default Button;
