import RadioButton from './RadioButton';
import { RadioButtonProps } from './RadioButton.type';

export type { RadioButtonProps };

export default RadioButton;